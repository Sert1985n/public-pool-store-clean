
(function(){
  const HOME_PORT = 8500;
  const PORTS = {btc:8501,bch:8502,bsv:8503,fb:8504,ltc:8505,btcs:8506,xec:8507,dgb:8508,dgbscrypt:8508,dgb_scrypt:8508,rvn:8509};
  const BRAND = "Public Pool";
  const NEEDLES_REMOVE = [
    "Molepool firmware for professional ASIC miners powered by GMiner",
    "Gate is a major international cryptocurrency exchange",
    "Anonymous Mining",
    "No Registration Required To Start.",
    "Multithreaded Stratum",
    "Ultra-low latency, asynchronous I/O.",
    "PoW Check",
    "Native code for maximum performance."
  ];
  const HEADING_REMOVE = ["Services","Agreements","Feedback"];
  const TEXT_REPLACE = [
    [/molepool\.com/gi, BRAND],
    [/\bMolepool\b/g, BRAND]
  ];

  function toLocalHost(coinHost){
    const key = (coinHost || "").toLowerCase().replace(".molepool.com","");
    const port = PORTS[key];
    return port ? `${location.protocol}//${location.hostname}:${port}` : `${location.protocol}//${location.hostname}:${HOME_PORT}`;
  }

  function rewriteUrl(url){
    try{
      if(!url) return url;
      const s = String(url);
      if(s.startsWith("https://id.molepool.com/api")) return s.replace("https://id.molepool.com/api", "/id-api");
      const m = s.match(/^https?:\/\/([a-z0-9_.-]+)\.molepool\.com(\/.*)?$/i);
      if(m){
        const local = toLocalHost(m[1] + ".molepool.com");
        return local + (m[2] || "/");
      }
      if(/:85\/#\/?$/.test(s)) return `${location.protocol}//${location.hostname}:${HOME_PORT}/`;
      return s;
    }catch(e){ return url; }
  }

  const _fetch = window.fetch;
  if (_fetch) {
    window.fetch = function(input, init){
      try{
        if (typeof input === "string") input = rewriteUrl(input);
        else if (input && typeof input.url === "string") input = rewriteUrl(input.url);
      }catch(e){}
      return _fetch.call(this, input, init);
    };
  }
  const _open = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function(method, url){
    try{ arguments[1] = rewriteUrl(url); }catch(e){}
    return _open.apply(this, arguments);
  };

  function replaceTextTree(root){
    if(!root) return;
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    let n;
    while((n = walker.nextNode())){
      let t = n.nodeValue;
      if(!t) continue;
      for(const [rx, repl] of TEXT_REPLACE) t = t.replace(rx, repl);
      n.nodeValue = t;
    }
  }

  function closestRemovable(el){
    if(!el) return null;
    return el.closest('.v-card,.card,.v-col,.col,[class*="col-"],.v-sheet,.v-list-item,section,article,td,div');
  }

  function removeByNeedle(needle){
    const all = Array.from(document.querySelectorAll('body *'));
    for(const el of all){
      const text = (el.innerText || "").trim();
      if(text && text.includes(needle)){
        const target = closestRemovable(el) || el;
        if(target && target !== document.body && target !== document.documentElement){
          target.remove();
          return true;
        }
      }
    }
    return false;
  }

  function rewriteLinks(){
    Array.from(document.querySelectorAll('a[href]')).forEach(a=>{
      const text = (a.textContent || "").trim();
      const href = a.getAttribute('href') || "";
      const newHref = rewriteUrl(href);
      if(newHref !== href) a.setAttribute('href', newHref);
      if(text === "Pools") a.setAttribute('href', `${location.protocol}//${location.hostname}:${HOME_PORT}/`);
      if(text === "Home" && String(location.port) !== String(HOME_PORT)) a.setAttribute('href', `${location.protocol}//${location.hostname}:${HOME_PORT}/`);
    });
  }

  function cleanupPartners(){
    Array.from(document.querySelectorAll('img')).forEach(img=>{
      const src = img.getAttribute('src') || "";
      if(src.includes('/partners/')){
        const target = img.closest('.v-col,.col,[class*="col-"],.v-row,div') || img;
        if(target && target !== document.body) target.remove();
      }
    });
  }

  function cleanupHeadings(){
    const all = Array.from(document.querySelectorAll('body *'));
    for(const heading of HEADING_REMOVE){
      for(const el of all){
        const text = (el.innerText || "").trim();
        if(text === heading){
          const target = closestRemovable(el) || el;
          if(target && target !== document.body) target.remove();
        }
      }
    }
  }

  function restyle(){
    if(document.title) document.title = document.title.replace(/Molepool/gi, BRAND).replace(/molepool\.com/gi, BRAND);
    Array.from(document.querySelectorAll('img[alt="Molepool"], img[title="logo"]')).forEach(img=>{
      img.setAttribute('alt', BRAND); img.setAttribute('title', BRAND);
    });
  }

  function tick(){
    try{
      rewriteLinks();
      for(const needle of NEEDLES_REMOVE) removeByNeedle(needle);
      cleanupHeadings();
      cleanupPartners();
      replaceTextTree(document.body);
      restyle();
    }catch(e){}
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', tick);
  tick();
  setInterval(tick, 1200);
})();
